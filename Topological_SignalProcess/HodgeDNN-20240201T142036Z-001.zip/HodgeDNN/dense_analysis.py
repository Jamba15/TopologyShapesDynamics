import matplotlib.pyplot as plt

from functions.analysis import *

configuration = {
    'type': 'Dense',
    'activation': 'relu',
    'hidden_layers': 1,
    'input_shape': 1,
    'hidden_size': 80,
    'use_bias': True,
    'last_size': 1,

    # Training Parameters
    'batch_size': 500,
    'epochs': 60,
    'learn_rate': 0.005,
    'loss': 'mse',
    'metrics': tf.keras.metrics.MSE,
    'last_activation': None,

    # Overall
    'dataset': 'function',
    'fname_savings': 'Test.pk'
}
n_trial = 20

hid_sizes = [10, 30, 50, 80, 100, 200]
means_w = np.zeros([n_trial, len(hid_sizes)])

for j, size in enumerate(hid_sizes):
    for i in range(n_trial):
        print('current size {}'.format(size))
        configuration['hidden_size'] = size

        if configuration['hidden_layers'] != 1:
            raise ValueError('Hidden layers at most 1!')
        (x_train, y_train), (x_test, y_test) = load_dataset(configuration['dataset'],
                                                            function=lambda x: x ** 3).load_train_test()

        sizes = [configuration['input_shape'],
                 configuration['hidden_size'],
                 configuration['last_size']]

        cc, B1, B2, imB1t, imB2 = bases_retrive(sizes,
                                                return_base=True)

        cells_list = cc.complex_list()
        full_base = np.concatenate([imB2, imB1t],
                                   axis=1)

        # %% Training
        model = build_feedforward(configuration)
        model.fit(x_train, y_train,
                  epochs=configuration['epochs'],
                  verbose=0)
        loss_before, binacc_before = model.evaluate(x_train, y_train)
        interval = [0.7, 0.8]
        new_x, new_y = function_modifier(x_train, y_train, lambda x: -x ** 0.6, interval)
        nm = type(model).__name__ + str(configuration['hidden_size'])
        data = show_diff(model, new_x, new_y)
        means_w[i, j] = data['delta_w'].mean()
#%%
err_w = means_w.std(axis=0)/np.sqrt(n_trial) # - means_w.min(axis=0))/2
fig, (ax_w) = plt.subplots(1, 1, figsize=(4, 4), dpi=200)
ax_w.errorbar(x=np.array(hid_sizes), y=means_w.mean(axis=0), yerr=err_w)
ax_w.set_title('weights mean relative variation')
plt.savefig('Dense_variation.png')
plt.show()

