from tensorflow import matmul
from tensorflow.keras import activations
from typing import List
from tensorflow.keras import Model
from tensorflow.keras.callbacks import Callback
import numpy as np
import tensorflow as tf
import os
import pickle as pk


class cohomology_train(Model):
    """
    3 lay feedforward NN trained inthe base of the images of boundary and coboundary
    operators
    """
    def __init__(self,
                 sizes: List,
                 imB1t: np.ndarray,
                 imB2: np.ndarray,
                 n_vet_B1t: int,
                 n_vet_B2: int,
                 config: dict):
        """
        :param sizes:
        :param imB1t: image span of B1T
        :param imB2: image span of B2
        :param n_vet_B1t: how many vectors of B1T use
        :param n_vet_B2: how many vectors of B2 use
        :param config: configuration file with activations and so on...
        """
        # Get local!!!!
        super(cohomology_train, self).__init__()
        self.imB1 = imB1t
        self.imB2 = imB2
        self.activation = activations.get(config['activation'])
        self.last_activation = activations.get(config['last_activation'])
        self.use_bias = config['use_bias']

        self.n1, self.n2, self.n3 = sizes

        n_vet_B1t = np.clip(n_vet_B1t,
                            a_min=0,
                            a_max=imB1t.shape[1])

        n_vet_B2 = np.clip(n_vet_B2,
                           a_min=0,
                           a_max=imB2.shape[1])

        self.imB1_base_0 = tf.constant(imB1t[:self.n1 * self.n2, :n_vet_B1t],
                                       dtype=tf.float32)
        self.imB1_base_1 = tf.constant(imB1t[self.n1 * self.n2:, :n_vet_B1t],
                                       dtype=tf.float32)

        self.imB2_base_0 = tf.constant(imB2[:self.n1 * self.n2, :n_vet_B2],
                                       dtype=tf.float32)
        self.imB2_base_1 = tf.constant(imB2[self.n1 * self.n2:, :n_vet_B2],
                                       dtype=tf.float32)

        self.coef_B1 = self.add_weight(
            name='coef_B1',
            shape=(n_vet_B1t, 1),
            initializer=tf.keras.initializers.RandomUniform(-1, 1),
            regularizer=None,
            dtype=self.dtype,
            trainable=True)

        self.coef_B2 = self.add_weight(
            name='coef_B2',
            shape=(n_vet_B2, 1),
            initializer=tf.keras.initializers.RandomUniform(-1, 1),
            regularizer=None,
            dtype=self.dtype,
            trainable=True)

        if self.use_bias:
            self.bias1 = self.add_weight(
                name='bias1',
                initializer=tf.keras.initializers.Zeros(),
                shape=(self.n2,),
                dtype=self.dtype,
                trainable=True)

            self.bias2 = self.add_weight(
                name='bias2',
                shape=(self.n3,),
                initializer=tf.keras.initializers.Zeros(),
                dtype=self.dtype,
                trainable=True)

        else:
            self.bias = None

    def call(self, inputs, training=None, mask=None):

        kernel0 = matmul(self.imB1_base_0, self.coef_B1, name='B1_lay0') + \
                  matmul(self.imB2_base_0, self.coef_B2, name='B2_lay0')

        kernel1 = matmul(self.imB1_base_1, self.coef_B1, name='B1_lay1') + \
                  matmul(self.imB2_base_1, self.coef_B2, name='B2_lay1')

        output_1 = matmul(a=inputs, b=tf.transpose(kernel0))

        if self.use_bias:
            output_1 = tf.nn.bias_add(output_1, self.bias1)

        if self.activation is not None:
            output_1 = self.activation(output_1)

        output_2 = matmul(a=output_1, b=kernel1)

        if self.use_bias:
            output_2 = tf.nn.bias_add(output_2, self.bias2)

        if self.last_activation is not None:
            output_2 = self.last_activation(output_2)

        return output_2

    def nn_weights(self,
                   mode='list'):

        if mode.lower().replace(" ", "") == 'list':
            if self.use_bias:
                return [[(matmul(self.imB1_base_0, self.coef_B1, name='B1_lay0') +
                          matmul(self.imB2_base_0, self.coef_B2, name='B2_lay0')).numpy(), self.bias1.numpy()],
                        [(matmul(self.imB1_base_1, self.coef_B1, name='B1_lay1') +
                          matmul(self.imB2_base_1, self.coef_B2, name='B2_lay1')).numpy(), self.bias2.numpy()]]
            else:
                return [[(matmul(self.imB1_base_0, self.coef_B1, name='B1_lay0') +
                          matmul(self.imB2_base_0, self.coef_B2, name='B2_lay0')).numpy()],
                        [(matmul(self.imB1_base_1, self.coef_B1, name='B1_lay1') +
                          matmul(self.imB2_base_1, self.coef_B2, name='B2_lay1')).numpy()]]

        if mode.lower().replace(" ", "") == 'vector':
            return matmul(tf.concat([self.imB1_base_0, self.imB1_base_1], axis=0), self.coef_B1) + \
                   matmul(tf.concat([self.imB2_base_0, self.imB2_base_1], axis=0), self.coef_B2)
        else:
            raise ValueError('Insert a valid return type: list, vector')

    def get_config(self):
        pass


class retrive_coefficients(Callback):
    """
    Gets projection along the given basis while training in the eigenvectors of the
    boundary operators
    """
    def __init__(self,
                 fname='Test.pk',
                 normalize_signal=False):
        super().__init__()
        self.base = tf.cast(tf.concat([self.imB1t, self.imB2], axis=1), dtype=tf.float32)
        self.norm_w = normalize_signal

        if os.path.exists(fname):
            os.remove(fname)
            print("File removed")
        else:
            print("The file does not exist")
        self.f_pointer = open(fname, 'ab')

    def on_epoch_end(self, epoch, logs=None):
        zeroB2 = self.imB2.shape[1] - self.model.imB2_base_0.shape[1]
        zeroB1 = self.imB1t.shape[1] - self.model.imB1_base_0.shape[1]

        if epoch % 2:
            pk.dump({'B1t': np.append(self.model.coef_B1.numpy(), np.zeros((zeroB1, 1))),
                     'B2': np.append(self.model.coef_B2.numpy(), np.zeros((zeroB2, 1)))},
                    self.f_pointer)
