from tensorflow.keras.callbacks import Callback
from myfunctions import *
import numpy as np
from typing import Callable
from os.path import join, dirname, abspath
from numba import njit
from warnings import warn
import matplotlib.pyplot as plt

current_dir = dirname(abspath(__file__))


def compare_edge(proj, onto):
    if (proj == onto).all():
        return 1
    elif (proj == onto[::-1]).all():
        return -1
    else:
        return 0


@njit
def cell_3_layers(n1, n2, n3):
    cells = []
    for i in range(n1):
        for j in range(n1, n1 + n2):
            for k in range(n1 + n2, n1 + n2 + n3):
                n = 1
                while j + n < n1 + n2:
                    cells.append([(i, j), (j, k), (k, j + n), (j + n, i)])
                    n += 1
    return cells


def edge_3_layers(n1, n2, n3):
    edges_0 = [(i, j) for i in range(n1) for j in range(n1, n1 + n2)]
    edges_1 = [(j, k) for j in range(n1, n1 + n2) for k in range(n1 + n2, n1 + n2 + n3)]
    return edges_0 + edges_1


def index_dict(edge):
    dict_edge = {e: (n, 1) for n, e in enumerate(edge)}
    dict_edge.update({e[::-1]: (n, -1) for n, e in enumerate(edge)})
    return dict_edge


def boundary_2(edge, cells):
    B2 = np.zeros((len(edge), len(cells)))
    places = index_dict(edge)
    for col, c in enumerate(cells):
        for e in c:
            B2[places[e][0], col] = places[e][1]
    return B2


def boundary_1(nodes, edges):
    B1 = np.zeros((nodes.shape[0], edges.shape[0]))
    for j in range(nodes.shape[0]):
        B1[j, nodes[j] == edges[:, 0]] = 1
        B1[j, nodes[j] == edges[:, 1]] = -1
    return B1


class feedforward_CC:
    def __init__(self,
                 layers: List):
        if len(layers) != 3 and not isinstance(layers[0], int):
            raise ValueError('Pass a list of 3 integers')

        self.n1, self.n2, self.n3 = layers

        self.edges = edge_3_layers(self.n1, self.n2, self.n3)
        self.cells = cell_3_layers(self.n1, self.n2, self.n3)

    def show_edges(self):
        print('\nEdges:\n')
        for k in self.edges:
            print(str(k))

    def show_cells(self):
        print('\nCells:\n')
        for c in self.cells:
            s = ''
            for e in c:
                s += str(e) + ','
            print('[' + s[:-1] + ']')

    def get_B2(self):
        return boundary_2(self.edges, self.cells)

    def get_B1(self):
        return boundary_1(np.array(list(range(self.n1 + self.n2 + self.n3))), np.array(self.edges))

    def get_L1(self):
        B1 = self.get_B1()
        B2 = self.get_B2()
        return B1.T @ B1 + B2 @ B2.T

    def get_L0(self):
        B1 = self.get_B1()
        return B1 @ B1.T

    def complex_list(self):
        tmp = []
        for k in self.cells:
            node_list = list(k[0])
            for e in k[1:-1]:
                node_list.append(e[1])
            tmp.append(node_list)
        return self.edges + tmp


class decompose_links(Callback):
    def __init__(self,
                 imB1t,
                 imB2,
                 fname='Test.pk',
                 normalize_signal=False):
        super().__init__()
        self.imB1t = tf.constant(imB1t, dtype=tf.float32)
        self.imB2 = tf.constant(imB2, dtype=tf.float32)
        self.base = tf.cast(tf.concat([imB1t, imB2], axis=1), dtype=tf.float32)
        self.norm_w = normalize_signal

        if os.path.exists(fname):
            fname.find('.')
            os.remove(fname)
            print("File removed")
        else:
            print("The file does not exist")
        self.f_pointer = open(fname, 'ab')

    def on_epoch_end(self, epoch, logs=None):
        if epoch % 2:
            w0 = self.model.layers[0].get_weights()[0].reshape([1, -1])
            w1 = self.model.layers[1].get_weights()[0].reshape([1, -1])
            w_signal = tf.cast(tf.transpose(tf.concat([w0, w1], axis=1)), dtype=tf.float32)
            proj = (tf.linalg.inv(self.base) @ w_signal).numpy()

            pk.dump({'B1t': proj[:self.imB1t.shape[1]],
                     'B2': proj[self.imB1t.shape[1]:self.imB1t.shape[1] + self.imB2.shape[1]]
                     },
                    self.f_pointer)


class decompose_grad(decompose_links):
    def __init__(self,
                 imB1t,
                 imB2,
                 fname='Test_grad.pk'):
        super(decompose_grad, self).__init__(imB1t,
                                             imB2,
                                             fname=fname)

        def on_epoch_end(self, epoch, logs=None):
            if epoch % 2:
                w0 = self.model.layers[0].get_weights()[0].reshape([1, -1])
                w1 = self.model.layers[1].get_weights()[0].reshape([1, -1])
                w_signal = tf.cast(tf.transpose(tf.concat([w0, w1], axis=1)), dtype=tf.float32)
                proj = (tf.linalg.inv(self.base) @ w_signal).numpy()

                pk.dump({'B1t': proj[:self.imB1t.shape[1]],
                         'B2': proj[self.imB1t.shape[1]:self.imB1t.shape[1] + self.imB2.shape[1]]
                         },
                        self.f_pointer)


def base_filter(model, full_base, how_many, sizes, norm=False):
    w0 = model.layers[0].get_weights()[0].reshape([1, -1])
    w1 = model.layers[1].get_weights()[0].reshape([1, -1])
    w_signal = np.concatenate([w0, w1], axis=1).T
    if norm:
        norm_signal = w_signal / np.linalg.norm(w_signal, axis=0)
    all_proj = (np.linalg.inv(full_base) @ w_signal)
    how_many = np.clip(how_many,
                       a_min=1,
                       a_max=all_proj.shape[0])

    all_proj[np.argsort(-abs(all_proj), axis=0)[how_many:, 0]] = 0
    filt_w = full_base @ all_proj
    w_list = reformat_weights_list(sizes, filt_w)
    return change_weights(model, w_list)


def weights_from_subspace(base: np.ndarray, model):
    sizes = [k.input_shape[-1] for k in model.layers] + [model.layers[-1].output_shape[-1]]
    rand_w = base @ np.random.uniform(-3, 3, [base.shape[1], 1])
    return change_weights(model, reformat_weights_list(sizes, rand_w))


def reformat_weights_list(sizes, weights):
    w_list = []
    i = 0
    for j in range(len(sizes) - 1):
        w_list.append(weights[i:i + sizes[j] * sizes[j + 1]].reshape([sizes[j], sizes[j + 1]]))
        i += sizes[j] * sizes[j + 1]
    return w_list


def bases_retrive(sizes: list, return_base=True, **kwargs):
    cc = feedforward_CC(sizes)
    B2 = cc.get_B2()
    B1 = cc.get_B1()

    if return_base:
        base_nm = '-'.join(str(e) for e in sizes)

        path_B1t = find(base_nm + 'B1t.pk', join(current_dir, '..'))
        if path_B1t:
            with open(path_B1t[0], 'rb') as f:
                imB1t = pk.load(f)
        else:
            # imB1t = orth(B1.T)
            imB1t = image_span(B1.T)
            with open(join(current_dir, '../Bases', base_nm + 'B1t.pk'), 'wb') as f:
                pk.dump(imB1t, f)

        path_B2 = find(base_nm + 'B2.pk', join(current_dir, '..'))
        if path_B2:
            with open(path_B2[0], 'rb') as f:
                imB2 = pk.load(f)
        else:
            imB2 = image_span(B2)

            with open(join(current_dir, '../Bases', base_nm + 'B2.pk'), 'wb') as f:
                pk.dump(imB2, f)
        decouple = kwargs.get('decouple', False)

        if decouple:
            warn('Decoupling with structure assumed 2 lay feedforward')
            imB1t = imB1t[:, 2:]
            imB1t = imB1t[:, :-1] + imB1t[:, 1:]
            tmp = np.roll(imB1t[:, 0], -1, 0)
            imB1t = np.concatenate([tmp[:, np.newaxis], imB1t], axis=1)
            imB2 = dec_B2(imB2, sizes)

        return cc, B1, B2, imB1t, imB2
    else:
        return cc, B1, B2


def dec_B2(imB2, sizes):
    n1, n2, n3 = sizes
    for l in range(n1 + n3):
        imB2[n2 * l, :] = 0

    l = 0
    for i in range(n1):
        np.fill_diagonal(imB2[i * n2:(i + 1) * n2 - 1, i * n2:(i + 1) * (n2 - 1)], 0.5)
    l = 1
    for i in range(n1):
        np.fill_diagonal(imB2[l * n1 * n2:l * n1 * n2 + n2, i * n2:(i + 1) * (n2 - 1)], 0.5)
    return imB2


def grad_vec_retriever(domain: np.ndarray,
                       model: tf.keras.Model,
                       ):
    """
    finds the relevant coefficients inside the given domain
    :param model:
    :param domain: interval compatibel with the function domain
    :return: vectors
    """
    with tf.GradientTape(persistent=True) as tape:
        gb1 = [tape.gradient(model(domain[k, np.newaxis]), model.trainable_variables)[0].numpy() for k in
               range(domain.shape[0])]
        gb2 = [tape.gradient(model(domain[k, np.newaxis]), model.trainable_variables)[1].numpy() for k in
               range(domain.shape[0])]

    gb1 = np.array(gb1)[:, :, 0]
    gb2 = np.array(gb2)[:, :, 0]

    # Soft filtering
    gb1[abs(gb1) < 0.01] = 0
    gb2[abs(gb2) < 0.01] = 0

    # Aggregating
    sum_gb1 = gb1.sum(axis=0)
    sum_gb2 = gb2.sum(axis=0)

    space_b1 = model.imB1.shape[1]
    space_b2 = model.imB2.shape[1]

    imB1_contr = model.imB1[:, np.pad(sum_gb1, (0, space_b1 - sum_gb1.shape[0])) != 0]
    imB2_contr = model.imB2[:, np.pad(sum_gb2, (0, space_b2 - sum_gb2.shape[0])) != 0]

    return {'grad_B1': sum_gb1,
            'grad_B2': sum_gb2,
            'B1_vectors': imB1_contr,
            'B2_vectors': imB2_contr}


def show_diff(model, new_x, new_y, **kwargs) -> None:
    data = None
    if type(model).__name__ == 'cohomology_train':
        old_b2 = model.coef_B2.numpy().reshape([-1])
        old_b1 = model.coef_B1.numpy().reshape([-1])
        fig, (ax_b1, ax_b2) = plt.subplots(1, 2, figsize=(9, 4), dpi=200)
        ax_b1.set_title('$\Delta$ B1 coefficient')
        ax_b2.set_title('$\Delta$ B2 coefficient')
    elif type(model).__name__ == 'Sequential':
        old_w = []
        for l in model.layers:
            old_w.append(l.get_weights()[0].reshape([-1]))
        old_w = np.concatenate(old_w, axis=0)
        fig, ax_w = plt.subplots(1, 1, figsize=(9, 4), dpi=200)
        ax_w.set_title('$\Delta$ W')
    else:
        print(type(model).__name__)
        raise ValueError('Wrong model type')
    model.fit(new_x, new_y,
              epochs=kwargs.get('epochs', 20),
              verbose=1)

    if type(model).__name__ == 'cohomology_train':
        new_b2 = model.coef_B2.numpy().reshape([-1])
        new_b1 = model.coef_B1.numpy().reshape([-1])
        delta_b2 = abs((new_b2 - old_b2) / old_b2)
        delta_b1 = abs((new_b1 - old_b1) / old_b1)
        delta_b1 /= delta_b1.max()
        delta_b2 /= delta_b2.max()

        data = {'delta_B1': delta_b1,
                'delta_B2': delta_b2
                }
        ax_b1.plot(delta_b1, '-bo')
        ax_b2.plot(delta_b2, '-ro')

    if type(model).__name__ == 'Sequential':
        new_w = []
        for l in model.layers:
            new_w.append(l.get_weights()[0].reshape([-1]))
        new_w = np.concatenate(new_w, axis=0)
        delta_w = abs((new_w - old_w) / old_w)
        delta_w /= delta_w.max()

        ax_w.plot(delta_w, '-ro')
        data = {'delta_w': delta_w}

    save = kwargs.get('save_fig', False)
    if save:
        nm = kwargs.get('name_fig', 'plot.png')
        plt.savefig(nm)

    plt.show()
    return data


def function_modifier(x_train, y_train, new_value: Callable, interval: list):
    indexes = np.logical_and((interval[0] < x_train), (x_train < interval[1]))
    v = np.sort(x_train[x_train > interval[0]])
    print(y_train.shape)
    print(indexes.shape)

    y_train[indexes] = new_value(x_train[indexes] - v[0]) + y_train[indexes]
    return x_train, y_train
