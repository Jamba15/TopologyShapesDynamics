import sys
from os.path import join
from pathlib import Path
sys.path.append(join(Path.home(), 'PycharmProjects', 'MyFunctions'))
