import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import cm
import itertools
from My_functions import *
from functions.analysis import grad_vec_retriever


class NN_drawer:
    ax: plt.Axes

    def __init__(self,
                 cell_complex):
        simplices = cell_complex.complex_list()
        self.nodes = list(set(itertools.chain(*simplices)))

        # List of 1-simplices and more
        edges = []
        cells = []
        for e in simplices:
            if len(e) == 2:
                edges.append(e)
            else:
                cells.append(e)
        self.edges = edges
        self.cells = cells
        ax = plt.gca()
        ax.set_xlim([-0.1, 1.1])
        ax.set_ylim([-0.1, 1.1])
        ax.get_xaxis().set_ticks([])
        ax.get_yaxis().set_ticks([])
        ax.axis('off')

        self.ax = ax

        self.pos = pos_nodes_lay(cell_complex.n1, cell_complex.n2, cell_complex.n3)

        for i in self.nodes:
            (x, y) = self.pos[i]
            r = 0.04
            circ = plt.Circle([x, y], radius=r, zorder=3, lw=0.5,
                              edgecolor='Black', facecolor=plt.cm.RdBu(0.5))
            self.ax.annotate(str(i), (x - r / 3, y - r / 3))
            self.ax.add_patch(circ)

    def plot_single_v(self, weights, **kwargs):
        multiple = kwargs.get('multiple', False)
        for k, (i, j) in enumerate(self.edges):

            (x0, y0) = self.pos[i]
            (x1, y1) = self.pos[j]

            if weights is None:
                w = 1
            else:
                w = weights[k]

            if abs(w) > 0.001:
                norm = kwargs.get('normalizer', mpl.colors.Normalize(vmin=-abs(weights).max(), vmax=abs(weights).max()))
                line = plt.Line2D([x0, x1], [y0, y1],
                                  color=plt.cm.seismic(norm(w)),
                                  zorder=2,
                                  lw=w)
                if w > 0:
                    v0_x, v0_y, v1_x, v1_y = x0, y0, (x1 - x0) / 1.5, (y1 - y0) / 1.5
                else:
                    v0_x, v0_y, v1_x, v1_y = x1, y1, -(x1 - x0) / 1.5, -(y1 - y0) / 1.5

                self.ax.arrow(v0_x, v0_y, v1_x, v1_y,
                              shape='full',
                              zorder=3,
                              lw=0,
                              color='k',
                              length_includes_head=False,
                              head_width=.05,
                              head_starts_at_zero=True)

            else:
                line = plt.Line2D([x0, x1], [y0, y1],
                                  color='grey',
                                  zorder=2,
                                  lw=.5)
            self.ax.add_line(line)

        if not multiple:
            return self.ax

    def plot_weights(self, weights, **kwargs):
        title = kwargs.get('title', None)
        self.ax.set_title(title)
        if isinstance(weights, np.ndarray):
            try:
                if weights.shape[1] < 2:
                    self.plot_single_v(weights)
            except IndexError:
                return self.plot_single_v(weights)
            else:
                for i in range(weights.shape[1]):
                    self.plot_single_v(weights[:, i], multiple=True)
                return self.ax
        if isinstance(weights, list):
            for w in weights:
                if len(weights) > 1:
                    m = False
                else:
                    m = True
                self.plot_single_v(w, multiple=m)
            return self.ax

    def plot_relevance(self, domain, model):
        tmp_dict = grad_vec_retriever(domain, model)
        grads = tmp_dict['grad_B2']
        edges_index = [np.nonzero(tmp_dict['B2_vectors'][:, k])[0] for k in range(tmp_dict['B2_vectors'].shape[1])]
        used_cell = [sorted(list(set(itertools.chain(*[self.edges[k] for k in ind])))) for ind in edges_index]
        norm = mpl.colors.Normalize(vmin=0, vmax=abs(grads).max())

        # Filling in the cells
        for n, (i, j, k, m) in enumerate(used_cell):
            (x0, y0) = self.pos[i]
            (x1, y1) = self.pos[j]
            (x2, y2) = self.pos[m]
            (x3, y3) = self.pos[k]

            tri = plt.Polygon([[x0, y0], [x1, y1], [x2, y2], [x3, y3]],
                              edgecolor='black', facecolor=plt.cm.GnBu(norm(abs(grads[n]))),
                              zorder=1, alpha=0.8, lw=0)
            self.ax.add_patch(tri)
        plt.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=plt.cm.GnBu),
                     orientation='vertical',
                     ax=self.ax)
        return self.ax, grads

    def plot_diff(self, coef0, model1):
        coef1 = np.pad(model1.coef_B2.numpy().reshape([-1]), (0, model1.imB2.shape[1]))
        im1 = model1.imB2

        edges_index = [np.nonzero(im1[:, k])[0] for k in range(im1.shape[1])]
        used_cell = [sorted(list(set(itertools.chain(*[self.edges[k] for k in ind])))) for ind in edges_index]
        norm = mpl.colors.Normalize(vmin=0, vmax=abs(coef0-coef1).max())

        # Filling in the cells
        for n, (i, j, k, m) in enumerate(used_cell):
            (x0, y0) = self.pos[i]
            (x1, y1) = self.pos[j]
            (x2, y2) = self.pos[m]
            (x3, y3) = self.pos[k]
            tri = plt.Polygon([[x0, y0], [x1, y1], [x2, y2], [x3, y3]],
                              edgecolor='black',
                              facecolor=plt.cm.GnBu(norm(abs(coef1-coef0)[n])),
                              zorder=1,
                              alpha=0.8,
                              lw=0)
            self.ax.add_patch(tri)
        plt.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=plt.cm.GnBu),
                     orientation='vertical',
                     ax=self.ax)
        return self.ax, coef1-coef0




def pos_nodes_lay(n1,
                  n2,
                  n3,
                  min_y=0,
                  max_y=1):
    lays = np.array([n1, n2, n3])
    max_nodes = lays.max()
    d = (max_y - min_y) / max_nodes
    mean = (max_y - min_y) / 2

    pos_dict = {i: [0, mean + n1 * d / 2 - i * d] for i in range(n1)}
    pos_dict.update({k: [0.5, mean + n2 * d / 2 - i * d] for i, k in enumerate(range(n1, n1 + n2))})
    pos_dict.update({k: [1, mean + n3 * d / 2 - i * d] for i, k in enumerate(range(n1 + n2, n1 + n2 + n3))})
    return pos_dict


def project_links(config: dict,
                  model: tf.keras.Sequential,
                  cell_complex=None,
                  represent_vec=None,
                  custom_vec=None,
                  plot_projections=True,
                  relative_increase=False,
                  normalize_proj=True,
                  last=True,
                  imB1t=None,
                  imB2=None,
                  return_ax_graph=False):
    output = {}
    proj_list = loadall(config['fname_savings'])
    B1t_proj = np.array([proj_list[k]['B1t'] for k in range(len(proj_list))])
    B2_proj = np.array([proj_list[k]['B2'] for k in range(len(proj_list))])

    if type(model).__name__ != 'cohomology_train':
        w0 = model.layers[0].get_weights()[0].reshape([1, -1])
        w1 = model.layers[1].get_weights()[0].reshape([1, -1])

        w_signal = np.concatenate([w0, w1], axis=1).T
    base = np.concatenate([imB2, imB1t], axis=1)

    if type(model).__name__ != 'cohomology_train':
        if normalize_proj:
            proj = np.linalg.inv(base) @ (w_signal / np.linalg.norm(w_signal, axis=0))
        else:
            proj = np.linalg.inv(base) @ w_signal
    else:
        zeroB2 = imB2.shape[1] - model.imB2_base_0.shape[1]
        zeroB1 = imB1t.shape[1] - model.imB1_base_0.shape[1]

        proj = np.concatenate([np.append(model.coef_B2.numpy(), np.zeros((zeroB2, 1))),
                               np.append(model.coef_B1.numpy(), np.zeros((zeroB1, 1)))], axis=0)

    if represent_vec is not None:
        most_important = represent_vec
        if imB2.shape[0] < 100:
            if custom_vec == 'B2':
                ind = represent_vec
            elif custom_vec == 'B1':
                ind = represent_vec + imB2.shape[1]
            else:
                if type(model).__name__ != 'cohomology_train':
                    ind = np.argsort(-abs(proj), axis=0)[most_important, 0]
                else:
                    ind = np.argsort(-abs(proj), axis=0)[most_important]

            if ind < imB2.shape[1]:
                title = '$B2$ vec: {}'.format(ind)
            else:
                title = r'$B1^\top$ vec: {}'.format(ind - imB2.shape[1])

            drawer = NN_drawer(cell_complex)
            asse = drawer.plot_relevance(np.arange(-1,-0.83,0.02).reshape([-1, 1]), model)
        if return_ax_graph:
            output.update({'ax_graph': asse})

    output.update({'indx ord': np.argsort(-abs(proj), axis=0)})

    if plot_projections:
        fig, (B1t_ax, B2_ax) = plt.subplots(1, 2, figsize=(8, 4))
        if type(model).__name__ != 'cohomology_train':
            B1t_plot = B1t_proj[:, :, 0].copy()
            B2_plot = B2_proj[:, :, 0].copy()
        else:
            B1t_plot = B1t_proj[:, :].copy()
            B2_plot = B2_proj[:, :].copy()

        if normalize_proj:
            if B1t_plot.shape[1] != 0:
                B1t_plot /= np.linalg.norm(B1t_plot, axis=1)[:, np.newaxis]
            if B2_plot.shape[1] != 0:
                B2_plot /= np.linalg.norm(B2_plot, axis=1)[:, np.newaxis]

        B1t_ax.plot(B1t_plot, alpha=0.4)
        B1t_ax.set_title(r'Im($grad$) = Im($B_1^\top$)')
        B2_ax.plot(B2_plot, alpha=0.4)
        B2_ax.set_title(r'Im($curl^\top$) = Im($B_2$)')
        plt.tight_layout()
        plt.show()
    if last:
        output.update({'Im_B2': B2_proj[-1], 'Im_B1t': B1t_proj[-1]})
    else:
        output.update({'Im_B2': B2_proj, 'Im_B1t': B1t_proj})

    if relative_increase:
        incrB1t = abs((B1t_proj[-1, :, 0] - B1t_proj[1, :, 0]) / B1t_proj[1, :, 0])
        incrB2 = abs((B2_proj[-1, :, 0] - B2_proj[1, :, 0]) / B2_proj[1, :, 0])
        output.update({'incrB1t': incrB1t, 'incrB2': incrB2})
    return output


def plot_function_xor(filt_xor):
    X = np.arange(0, 1, 0.025)
    Y = np.arange(0, 1, 0.025)
    X, Y = np.meshgrid(X, Y)

    D = np.array([[X[i, j], Y[i, j]] for i in range(X.shape[0]) for j in range(X.shape[1])])
    Z = filt_xor(D).numpy()

    fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
    surf = ax.plot_surface(X, Y, Z.reshape([40, 40]), cmap=cm.coolwarm,
                           linewidth=0, antialiased=False)

    ax.view_init(elev=30., azim=70)
    plt.show()
