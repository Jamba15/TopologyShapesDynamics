from functions.analysis import *
from functions.models import *

configuration = {
    'type': 'Dense',
    'activation': 'relu',
    'hidden_layers': 1,
    'input_shape': 1,
    'hidden_size': 80,
    'use_bias': True,
    'last_size': 1,

    # Training Parameters
    'batch_size': 500,
    'epochs': 60,
    'dataset': 'function',
    'learn_rate': 0.005,
    'loss': 'mse',
    'metrics': tf.keras.metrics.MSE,
    'last_activation': None,

    'fname_savings': 'Test.pk'
}
n_trial = 20
hid_sizes = [10, 30, 50, 80, 100, 200]
means_b2 = np.zeros([n_trial, len(hid_sizes)])
means_b1 = np.zeros([n_trial, len(hid_sizes)])

for j, size in enumerate(hid_sizes):
    for i in range(n_trial):
        print('current size {}'.format(size))
        tf.keras.backend.clear_session()
        configuration['hidden_size'] = size

        if configuration['hidden_layers'] != 1:
            raise ValueError('Hidden layers at most 1!')

        (x_train, y_train), (x_test, y_test) = load_dataset(configuration['dataset'],
                                                            function=lambda x: x ** 3).load_train_test()

        sizes = [configuration['input_shape'],
                 configuration['hidden_size'],
                 configuration['last_size']]
        cc, B1, B2, imB1t, imB2 = bases_retrive(sizes,
                                                return_base=True,
                                                decouple=True)
        # %%
        model = cohomology_train(sizes=sizes,
                                 imB1t=imB1t,
                                 imB2=imB2,
                                 n_vet_B1t=1000,
                                 n_vet_B2=1000,
                                 config=configuration)

        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=configuration['learn_rate']),
                      loss=configuration['loss'],
                      metrics=configuration['metrics'],
                      run_eagerly=False)

        model.fit(x_train, y_train,
                  epochs=configuration['epochs'],
                  verbose=0)

        loss_before, binacc_before = model.evaluate(x_test, y_test)



        # %% New datasets and model
        interval = [0.7, 0.8]
        new_x, new_y = function_modifier(x_train, y_train, lambda x: -x ** 0.6, interval)
        nm = type(model).__name__ + str(configuration['hidden_size'])
        data = show_diff(model, new_x, new_y)
        means_b1[i, j] = data['delta_B1'].mean()
        means_b2[i, j] = data['delta_B2'].mean()
#%%
err_b1 = means_b1.std(axis=0)/np.sqrt(n_trial)  # (means_b1.max(axis=0) - means_b1.min(axis=0))/2
err_b2 = means_b2.std(axis=0)/np.sqrt(n_trial)  # (means_b2.max(axis=0) - means_b2.min(axis=0))/2
fig, (ax_b1, ax_b2) = plt.subplots(1, 2, figsize=(9, 4), dpi=200)
ax_b1.errorbar(x=np.array(hid_sizes), y=means_b1.mean(axis=0), yerr=err_b1)
ax_b2.errorbar(x=np.array(hid_sizes), y=means_b2.mean(axis=0), yerr=err_b2)
ax_b1.set_title('B1 coef. mean relative variation')
ax_b2.set_title('B2 coef. mean relative variation')
plt.savefig('Hodge_variation.png')
plt.show()
